const { body } = require('express-validator');

const registerValidator = [
    body('username')
        .isLength({ min: 6 })
        .withMessage('Логин должен содержать минимум 6 символов')
        .matches(/^[a-zA-Z0-9]+$/)
        .withMessage('Логин должен содержать только латиницу и цифры'),
    body('password')
        .isLength({ min: 8 })
        .withMessage('Пароль должен содержать минимум 8 символов'),
    body('full_name')
        .matches(/^[а-яА-ЯёЁ\s]+$/)
        .withMessage('ФИО должно содержать только кириллицу и пробелы'),
    body('phone')
        .matches(/^8\d{10}$/)
        .withMessage('Телефон должен быть в формате 8XXXXXXXXXX (11 цифр, начинается с 8)'),
    body('email')
        .isEmail()
        .withMessage('Введите корректный email')
];

const loginValidator = [
    body('username').notEmpty().withMessage('Введите логин'),
    body('password').notEmpty().withMessage('Введите пароль')
];

const applicationValidator = [
    body('course_name').notEmpty().withMessage('Введите название курса'),
    body('start_date').isDate().withMessage('Введите корректную дату'),
    body('payment_method').isIn(['cash', 'bank_transfer']).withMessage('Выберите способ оплаты')
];

const reviewValidator = [
    body('rating').isInt({ min: 1, max: 5 }).withMessage('Рейтинг должен быть от 1 до 5'),
    body('comment').optional().isString()
];

module.exports = {
    registerValidator,
    loginValidator,
    applicationValidator,
    reviewValidator
};
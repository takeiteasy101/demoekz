const db = require('../config/database');

class Review {
    static async create(reviewData) {
        const [result] = await db.execute(
            'INSERT INTO reviews (user_id, application_id, rating, comment) VALUES (?, ?, ?, ?)',
            [reviewData.user_id, reviewData.application_id, reviewData.rating, reviewData.comment]
        );
        return result.insertId;
    }

    static async findByApplicationId(applicationId) {
        const [rows] = await db.execute(
            'SELECT * FROM reviews WHERE application_id = ?',
            [applicationId]
        );
        return rows[0];
    }
}

module.exports = Review;
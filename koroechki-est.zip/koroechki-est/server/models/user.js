const db = require('../config/database');

class User {
    static async create(userData) {
        const [result] = await db.execute(
            'INSERT INTO users (username, password, full_name, phone, email) VALUES (?, ?, ?, ?, ?)',
            [userData.username, userData.password, userData.full_name, userData.phone, userData.email]
        );
        return result.insertId;
    }

    static async findByUsername(username) {
        const [rows] = await db.execute(
            'SELECT * FROM users WHERE username = ?',
            [username]
        );
        return rows[0];
    }

    static async findByEmail(email) {
        const [rows] = await db.execute(
            'SELECT * FROM users WHERE email = ?',
            [email]
        );
        return rows[0];
    }

    static async findById(id) {
        const [rows] = await db.execute(
            'SELECT id, username, full_name, phone, email, created_at, is_admin FROM users WHERE id = ?',
            [id]
        );
        return rows[0];
    }
}

module.exports = User;
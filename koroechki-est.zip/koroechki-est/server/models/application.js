const db = require('../config/database');

class Application {
    static async create(applicationData) {
        const [result] = await db.execute(
            'INSERT INTO applications (user_id, course_name, start_date, payment_method) VALUES (?, ?, ?, ?)',
            [applicationData.user_id, applicationData.course_name, applicationData.start_date, applicationData.payment_method]
        );
        return result.insertId;
    }

    static async findByUserId(userId) {
        const [rows] = await db.execute(
            `SELECT a.*, 
                    (SELECT COUNT(*) FROM reviews r WHERE r.application_id = a.id) as has_review
             FROM applications a 
             WHERE user_id = ? 
             ORDER BY created_at DESC`,
            [userId]
        );
        return rows;
    }

    static async findAll() {
        const [rows] = await db.execute(
            `SELECT a.*, u.full_name, u.email 
             FROM applications a 
             JOIN users u ON a.user_id = u.id 
             ORDER BY a.created_at DESC`
        );
        return rows;
    }

    static async updateStatus(id, status) {
        const [result] = await db.execute(
            'UPDATE applications SET status = ? WHERE id = ?',
            [status, id]
        );
        return result.affectedRows;
    }

    static async findById(id) {
        const [rows] = await db.execute(
            'SELECT * FROM applications WHERE id = ?',
            [id]
        );
        return rows[0];
    }
}

module.exports = Application;
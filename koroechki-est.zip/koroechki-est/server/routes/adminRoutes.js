const express = require('express');
const router = express.Router();
const AdminController = require('../controllers/adminController');
const { authMiddleware, adminMiddleware } = require('../middleware/authMiddleware');

router.get('/applications', authMiddleware, adminMiddleware, AdminController.getAllApplications);
router.put('/applications/:id/status', authMiddleware, adminMiddleware, AdminController.updateApplicationStatus);

module.exports = router;
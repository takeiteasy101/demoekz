const express = require('express');
const router = express.Router();
const ApplicationController = require('../controllers/applicationController');
const { applicationValidator, reviewValidator } = require('../utils/validators');
const { authMiddleware } = require('../middleware/authMiddleware');

router.post('/', authMiddleware, applicationValidator, ApplicationController.create);
router.get('/my', authMiddleware, ApplicationController.getUserApplications);
router.post('/review', authMiddleware, reviewValidator, ApplicationController.addReview);

module.exports = router;
const express = require('express');
const router = express.Router();
const AuthController = require('../controllers/authController');
const { registerValidator, loginValidator } = require('../utils/validators');
const { authMiddleware } = require('../middleware/authMiddleware');

router.post('/register', registerValidator, AuthController.register);
router.post('/login', loginValidator, AuthController.login);
router.post('/logout', AuthController.logout);
router.get('/profile', authMiddleware, AuthController.getProfile);

module.exports = router;
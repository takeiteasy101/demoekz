const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { validationResult } = require('express-validator');
const User = require('../models/user');

class AuthController {
    static async register(req, res) {
    try {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({ errors: errors.array() });
        }

        let { username, password, full_name, phone, email } = req.body;

        // Форматируем телефон для хранения в БД
        // Если телефон в формате 89994443232, преобразуем в 8(999)444-32-32
        if (/^8\d{10}$/.test(phone)) {
            const match = phone.match(/^8(\d{3})(\d{3})(\d{2})(\d{2})$/);
            if (match) {
                phone = `8(${match[1]})${match[2]}-${match[3]}-${match[4]}`;
            }
        }

        // Проверка существования пользователя
        const existingUser = await User.findByUsername(username);
        if (existingUser) {
            return res.status(400).json({ message: 'Пользователь с таким логином уже существует' });
        }

        const existingEmail = await User.findByEmail(email);
        if (existingEmail) {
            return res.status(400).json({ message: 'Пользователь с таким email уже существует' });
        }

        // Хеширование пароля
        const hashedPassword = await bcrypt.hash(password, 10);

        // Создание пользователя
        const userId = await User.create({
            username,
            password: hashedPassword,
            full_name,
            phone,
            email
        });

        // Создание JWT токена
        const token = jwt.sign(
            { id: userId, username, is_admin: false },
            process.env.JWT_SECRET || 'your-secret-key',
            { expiresIn: '24h' }
        );

        req.session.token = token;
        res.status(201).json({ 
            message: 'Пользователь успешно создан', 
            token,
            user: {
                id: userId,
                username,
                full_name,
                phone,
                email
            }
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Ошибка сервера' });
    }
}

    static async login(req, res) {
        try {
            const errors = validationResult(req);
            if (!errors.isEmpty()) {
                return res.status(400).json({ errors: errors.array() });
            }

            const { username, password } = req.body;

            // Поиск пользователя
            const user = await User.findByUsername(username);
            if (!user) {
                return res.status(401).json({ message: 'Неверный логин или пароль' });
            }

            // Проверка пароля
            const isPasswordValid = await bcrypt.compare(password, user.password);
            if (!isPasswordValid) {
                return res.status(401).json({ message: 'Неверный логин или пароль' });
            }

            // Создание JWT токена
            const token = jwt.sign(
                { 
                    id: user.id, 
                    username: user.username, 
                    is_admin: user.is_admin 
                },
                process.env.JWT_SECRET || 'your-secret-key',
                { expiresIn: '24h' }
            );

            req.session.token = token;
            req.session.userId = user.id;
            req.session.isAdmin = user.is_admin;

            res.json({ 
                message: 'Авторизация успешна', 
                token,
                user: {
                    id: user.id,
                    username: user.username,
                    full_name: user.full_name,
                    is_admin: user.is_admin
                }
            });
        } catch (error) {
            console.error(error);
            res.status(500).json({ message: 'Ошибка сервера' });
        }
    }

    static async logout(req, res) {
        req.session.destroy();
        res.json({ message: 'Выход выполнен успешно' });
    }

    static async getProfile(req, res) {
        try {
            const user = await User.findById(req.user.id);
            if (!user) {
                return res.status(404).json({ message: 'Пользователь не найден' });
            }
            res.json(user);
        } catch (error) {
            console.error(error);
            res.status(500).json({ message: 'Ошибка сервера' });
        }
    }
}

module.exports = AuthController;
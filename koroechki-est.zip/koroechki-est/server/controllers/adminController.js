const Application = require('../models/application');

class AdminController {
    static async getAllApplications(req, res) {
        try {
            const applications = await Application.findAll();
            res.json(applications);
        } catch (error) {
            console.error(error);
            res.status(500).json({ message: 'Ошибка сервера' });
        }
    }

    static async updateApplicationStatus(req, res) {
        try {
            const { id } = req.params;
            const { status } = req.body;

            if (!['new', 'in_progress', 'completed'].includes(status)) {
                return res.status(400).json({ message: 'Неверный статус' });
            }

            const affectedRows = await Application.updateStatus(id, status);
            
            if (affectedRows === 0) {
                return res.status(404).json({ message: 'Заявка не найдена' });
            }

            res.json({ message: 'Статус заявки обновлен' });
        } catch (error) {
            console.error(error);
            res.status(500).json({ message: 'Ошибка сервера' });
        }
    }
}

module.exports = AdminController;
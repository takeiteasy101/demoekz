const { validationResult } = require('express-validator');
const Application = require('../models/application');
const Review = require('../models/review');

class ApplicationController {
    static async create(req, res) {
        try {
            const errors = validationResult(req);
            if (!errors.isEmpty()) {
                return res.status(400).json({ errors: errors.array() });
            }

            const { course_name, start_date, payment_method } = req.body;

            const applicationId = await Application.create({
                user_id: req.user.id,
                course_name,
                start_date,
                payment_method
            });

            res.status(201).json({ 
                message: 'Заявка успешно создана', 
                applicationId 
            });
        } catch (error) {
            console.error(error);
            res.status(500).json({ message: 'Ошибка сервера' });
        }
    }

    static async getUserApplications(req, res) {
        try {
            const applications = await Application.findByUserId(req.user.id);
            res.json(applications);
        } catch (error) {
            console.error(error);
            res.status(500).json({ message: 'Ошибка сервера' });
        }
    }

    static async addReview(req, res) {
        try {
            const errors = validationResult(req);
            if (!errors.isEmpty()) {
                return res.status(400).json({ errors: errors.array() });
            }

            const { application_id, rating, comment } = req.body;

            // Проверка, существует ли заявка и принадлежит ли пользователю
            const application = await Application.findById(application_id);
            if (!application || application.user_id !== req.user.id) {
                return res.status(404).json({ message: 'Заявка не найдена' });
            }

            // Проверка, оставлен ли уже отзыв
            const existingReview = await Review.findByApplicationId(application_id);
            if (existingReview) {
                return res.status(400).json({ message: 'Отзыв уже оставлен' });
            }

            const reviewId = await Review.create({
                user_id: req.user.id,
                application_id,
                rating,
                comment
            });

            res.status(201).json({ 
                message: 'Отзыв успешно добавлен', 
                reviewId 
            });
        } catch (error) {
            console.error(error);
            res.status(500).json({ message: 'Ошибка сервера' });
        }
    }
}

module.exports = ApplicationController;
class KoroechkiApp {
    constructor() {
        this.token = localStorage.getItem('token');
        this.user = JSON.parse(localStorage.getItem('user'));
        this.baseUrl = '/api';
        this.init();
    }

    init() {
        this.bindEvents();
        this.checkAuth();
    }

    bindEvents() {
        // Навигация
        document.getElementById('showRegister')?.addEventListener('click', (e) => {
            e.preventDefault();
            this.showForm('register');
        });
        
        document.getElementById('showLogin')?.addEventListener('click', (e) => {
            e.preventDefault();
            this.showForm('login');
        });

        // Формы
        document.getElementById('loginForm')?.addEventListener('submit', (e) => {
            e.preventDefault();
            this.login();
        });

        document.getElementById('registerForm')?.addEventListener('submit', (e) => {
            e.preventDefault();
            this.register();
        });

        // Пользовательские действия
        document.getElementById('btnApplications')?.addEventListener('click', () => this.loadApplications());
        document.getElementById('btnNewApplication')?.addEventListener('click', () => this.showNewApplicationForm());
        document.getElementById('btnLogout')?.addEventListener('click', () => this.logout());

        // Администраторские действия
        document.getElementById('btnAllApplications')?.addEventListener('click', () => this.loadAllApplications());
        document.getElementById('btnAdminLogout')?.addEventListener('click', () => this.logout());
    }

    checkAuth() {
        if (this.token && this.user) {
            if (this.user.is_admin) {
                this.showAdminSection();
            } else {
                this.showUserSection();
            }
        } else {
            this.showAuthSection();
        }
    }

    showForm(formType) {
        document.getElementById('login-form').style.display = 
            formType === 'login' ? 'block' : 'none';
        document.getElementById('register-form').style.display = 
            formType === 'register' ? 'block' : 'none';
    }

    showAuthSection() {
        document.getElementById('auth-section').style.display = 'block';
        document.getElementById('user-section').style.display = 'none';
        document.getElementById('admin-section').style.display = 'none';
        this.showForm('login');
    }

    showUserSection() {
        document.getElementById('auth-section').style.display = 'none';
        document.getElementById('user-section').style.display = 'block';
        document.getElementById('admin-section').style.display = 'none';
        this.loadApplications();
    }

    showAdminSection() {
        document.getElementById('auth-section').style.display = 'none';
        document.getElementById('user-section').style.display = 'none';
        document.getElementById('admin-section').style.display = 'block';
        this.loadAllApplications();
    }

    async login() {
        const username = document.getElementById('loginUsername').value;
        const password = document.getElementById('loginPassword').value;

        try {
            const response = await fetch(`${this.baseUrl}/auth/login`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ username, password })
            });

            const data = await response.json();

            if (response.ok) {
                this.token = data.token;
                this.user = data.user;
                localStorage.setItem('token', this.token);
                localStorage.setItem('user', JSON.stringify(this.user));
                
                if (this.user.is_admin) {
                    this.showAdminSection();
                } else {
                    this.showUserSection();
                }
            } else {
                this.showError(data.message || 'Ошибка авторизации');
            }
        } catch (error) {
            this.showError('Ошибка подключения к серверу');
        }
    }

    async register() {
        const userData = {
            username: document.getElementById('regUsername').value,
            password: document.getElementById('regPassword').value,
            full_name: document.getElementById('regFullName').value,
            phone: document.getElementById('regPhone').value,
            email: document.getElementById('regEmail').value
        };

        try {
            const response = await fetch(`${this.baseUrl}/auth/register`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(userData)
            });

            const data = await response.json();

            if (response.ok) {
                this.showSuccess('Регистрация успешна! Теперь выполните вход.');
                this.showForm('login');
            } else {
                this.showError(data.message || data.errors?.[0]?.msg || 'Ошибка регистрации');
            }
        } catch (error) {
            this.showError('Ошибка подключения к серверу');
        }
    }

    async loadApplications() {
        try {
            const response = await fetch(`${this.baseUrl}/applications/my`, {
                headers: { 'Authorization': `Bearer ${this.token}` }
            });

            const applications = await response.json();

            if (response.ok) {
                this.renderApplications(applications);
            } else {
                this.showError('Ошибка загрузки заявок');
            }
        } catch (error) {
            this.showError('Ошибка подключения к серверу');
        }
    }

    renderApplications(applications) {
        const content = document.getElementById('content');
        
        if (applications.length === 0) {
            content.innerHTML = `
                <div class="application-card">
                    <p>У вас пока нет заявок на обучение.</p>
                    <button onclick="app.showNewApplicationForm()">Создать первую заявку</button>
                </div>
            `;
            return;
        }

        let html = '<h2>Мои заявки</h2>';
        
        applications.forEach(app => {
            const statusText = {
                'new': 'Новая',
                'in_progress': 'Идет обучение',
                'completed': 'Обучение завершено'
            }[app.status] || app.status;

            const statusClass = `status-${app.status}`;
            
            html += `
                <div class="application-card ${statusClass}">
                    <h3>${app.course_name}</h3>
                    <p><strong>Дата начала:</strong> ${new Date(app.start_date).toLocaleDateString('ru-RU')}</p>
                    <p><strong>Способ оплаты:</strong> ${app.payment_method === 'cash' ? 'Наличные' : 'Банковский перевод'}</p>
                    <p><strong>Статус:</strong> ${statusText}</p>
                    <p><strong>Дата подачи:</strong> ${new Date(app.created_at).toLocaleDateString('ru-RU')}</p>
                    
                    ${app.status === 'completed' && !app.has_review ? `
                        <div class="review-form">
                            <h4>Оставить отзыв о курсе</h4>
                            <form onsubmit="app.addReview(event, ${app.id})">
                                <div>
                                    <label>Оценка:</label>
                                    <select name="rating" required>
                                        <option value="5">★★★★★</option>
                                        <option value="4">★★★★☆</option>
                                        <option value="3">★★★☆☆</option>
                                        <option value="2">★★☆☆☆</option>
                                        <option value="1">★☆☆☆☆</option>
                                    </select>
                                </div>
                                <textarea name="comment" placeholder="Ваш отзыв..." rows="3"></textarea>
                                <button type="submit">Отправить отзыв</button>
                            </form>
                        </div>
                    ` : ''}
                    
                    ${app.has_review ? '<p><em>Вы уже оставили отзыв по этой заявке</em></p>' : ''}
                </div>
            `;
        });

        content.innerHTML = html;
    }

    showNewApplicationForm() {
        const content = document.getElementById('content');
        
        content.innerHTML = `
            <h2>Новая заявка на обучение</h2>
            <div class="form-container">
                <form id="newApplicationForm" onsubmit="app.createApplication(event)">
                    <input type="text" name="course_name" placeholder="Название курса" required>
                    <input type="date" name="start_date" required min="${new Date().toISOString().split('T')[0]}">
                    <select name="payment_method" required>
                        <option value="">Выберите способ оплаты</option>
                        <option value="cash">Наличные</option>
                        <option value="bank_transfer">Банковский перевод</option>
                    </select>
                    <button type="submit">Отправить заявку</button>
                </form>
            </div>
        `;
    }

    async createApplication(event) {
        event.preventDefault();
        const form = event.target;
        const formData = new FormData(form);
        const data = Object.fromEntries(formData.entries());

        try {
            const response = await fetch(`${this.baseUrl}/applications`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${this.token}`
                },
                body: JSON.stringify(data)
            });

            const result = await response.json();

            if (response.ok) {
                this.showSuccess('Заявка успешно отправлена на рассмотрение!');
                this.loadApplications();
            } else {
                this.showError(result.message || 'Ошибка создания заявки');
            }
        } catch (error) {
            this.showError('Ошибка подключения к серверу');
        }
    }

    async addReview(event, applicationId) {
        event.preventDefault();
        const form = event.target;
        const formData = new FormData(form);
        const data = {
            application_id: applicationId,
            rating: parseInt(formData.get('rating')),
            comment: formData.get('comment')
        };

        try {
            const response = await fetch(`${this.baseUrl}/applications/review`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${this.token}`
                },
                body: JSON.stringify(data)
            });

            const result = await response.json();

            if (response.ok) {
                this.showSuccess('Отзыв успешно добавлен!');
                this.loadApplications();
            } else {
                this.showError(result.message || 'Ошибка добавления отзыва');
            }
        } catch (error) {
            this.showError('Ошибка подключения к серверу');
        }
    }

    async loadAllApplications() {
        try {
            const response = await fetch(`${this.baseUrl}/admin/applications`, {
                headers: { 'Authorization': `Bearer ${this.token}` }
            });

            const applications = await response.json();

            if (response.ok) {
                this.renderAllApplications(applications);
            } else {
                this.showError('Ошибка загрузки заявок');
            }
        } catch (error) {
            this.showError('Ошибка подключения к серверу');
        }
    }

    renderAllApplications(applications) {
        const content = document.getElementById('admin-content');
        
        if (applications.length === 0) {
            content.innerHTML = '<p>Нет заявок на рассмотрение.</p>';
            return;
        }

        let html = `
            <h3>Все заявки (${applications.length})</h3>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Студент</th>
                        <th>Курс</th>
                        <th>Дата начала</th>
                        <th>Способ оплаты</th>
                        <th>Статус</th>
                        <th>Дата подачи</th>
                        
                    </tr>
                </thead>
                <tbody>
        `;

        applications.forEach(app => {
            const statusText = {
                'new': 'Новая',
                'in_progress': 'Идет обучение',
                'completed': 'Обучение завершено'
            }[app.status] || app.status;

            html += `
                <tr>
                    <td>${app.id}</td>
                    <td>${app.full_name}<br><small>${app.email}</small></td>
                    <td>${app.course_name}</td>
                    <td>${new Date(app.start_date).toLocaleDateString('ru-RU')}</td>
                    <td>${app.payment_method === 'cash' ? 'Наличные' : 'Банковский перевод'}</td>
                    <td>
                        <select class="status-select" data-id="${app.id}" onchange="app.updateApplicationStatus(${app.id}, this.value)">
                            <option value="new" ${app.status === 'new' ? 'selected' : ''}>Новая</option>
                            <option value="in_progress" ${app.status === 'in_progress' ? 'selected' : ''}>Идет обучение</option>
                            <option value="completed" ${app.status === 'completed' ? 'selected' : ''}>Обучение завершено</option>
                        </select>
                    </td>
                    <td>${new Date(app.created_at).toLocaleDateString('ru-RU')}</td>
                   
                </tr>
            `;
        });

        html += '</tbody></table>';
        content.innerHTML = html;
    }

    async updateApplicationStatus(applicationId, status) {
        try {
            const response = await fetch(`${this.baseUrl}/admin/applications/${applicationId}/status`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${this.token}`
                },
                body: JSON.stringify({ status })
            });

            const result = await response.json();

            if (response.ok) {
                this.showSuccess('Статус обновлен');
            } else {
                this.showError(result.message || 'Ошибка обновления статуса');
            }
        } catch (error) {
            this.showError('Ошибка подключения к серверу');
        }
    }

    async logout() {
        try {
            await fetch(`${this.baseUrl}/auth/logout`, {
                method: 'POST',
                headers: { 'Authorization': `Bearer ${this.token}` }
            });
        } catch (error) {
            // Игнорируем ошибки при выходе
        }

        localStorage.removeItem('token');
        localStorage.removeItem('user');
        this.token = null;
        this.user = null;
        this.showAuthSection();
    }

    showError(message) {
        const errorDiv = document.createElement('div');
        errorDiv.className = 'error';
        errorDiv.textContent = message;
        
        const container = document.querySelector('.container main');
        container.insertBefore(errorDiv, container.firstChild);
        
        setTimeout(() => errorDiv.remove(), 5000);
    }

    showSuccess(message) {
        const successDiv = document.createElement('div');
        successDiv.className = 'success';
        successDiv.textContent = message;
        
        const container = document.querySelector('.container main');
        container.insertBefore(successDiv, container.firstChild);
        
        setTimeout(() => successDiv.remove(), 5000);
    }
    // Функция для форматирования телефона
    formatPhoneNumber(phone) {
    // Удаляем все нецифровые символы
        const cleaned = phone.replace(/\D/g, '');
    
    // Проверяем, начинается ли с 8 и имеет 11 цифр
        if (/^8\d{10}$/.test(cleaned)) {
        return cleaned;
    }
    
    // Пробуем другие форматы
        if (/^7\d{10}$/.test(cleaned)) {
        return '8' + cleaned.substring(1);
    }
    
        return phone;
}

// Обновим функцию register
        async register() {
        const userData = {
        username: document.getElementById('regUsername').value,
        password: document.getElementById('regPassword').value,
        full_name: document.getElementById('regFullName').value,
        phone: this.formatPhoneNumber(document.getElementById('regPhone').value),
        email: document.getElementById('regEmail').value
    };

    // Валидация телефона
        if (!/^8\d{10}$/.test(userData.phone)) {
        this.showError('Телефон должен быть в формате 8XXXXXXXXXX (11 цифр, начинается с 8)');
        return;
    }

        try {
        const response = await fetch(`${this.baseUrl}/auth/register`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(userData)
        });

        const data = await response.json();

        if (response.ok) {
            this.showSuccess('Регистрация успешна! Теперь выполните вход.');
            this.showForm('login');
        } else {
            this.showError(data.message || data.errors?.[0]?.msg || 'Ошибка регистрации');
        }
    } catch (error) {
        this.showError('Ошибка подключения к серверу');
    }
}

}

// Инициализация приложения
const app = new KoroechkiApp();